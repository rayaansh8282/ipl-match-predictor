import pandas as pd

from src.data import normalize_team
from src.features import FeatureBuilder, build_dataset


def test_first_match_has_neutral_features():
    fb = FeatureBuilder()
    f = fb.features("A", "B", "V", "A", "bat")
    assert f["elo_diff"] == 0 and f["form_diff"] == 0 and f["h2h_rate"] == 0.5


def test_no_leakage_features_built_before_update():
    df = pd.DataFrame([
        dict(team1="A", team2="B", venue="V", toss_winner="A", toss_decision="bat", winner="A", year=2020),
        dict(team1="A", team2="B", venue="V", toss_winner="B", toss_decision="bat", winner="B", year=2020),
    ])
    X, y, _, _ = build_dataset(df)
    assert X.loc[0, "elo_diff"] == 0   # nothing known before match 1
    assert X.loc[1, "elo_diff"] > 0    # A's win is only visible from match 2


def test_team_rename():
    assert normalize_team("Delhi Daredevils") == "Delhi Capitals"
