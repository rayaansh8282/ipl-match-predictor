# Data

Download an IPL matches dataset from Kaggle (e.g. "IPL Complete Dataset 2008-2024")
and place `matches.csv` in this folder.

Required columns: `date, team1, team2, toss_winner, toss_decision, venue, winner`
(and optionally `result`, which is used to drop "no result" matches).

No internet or Kaggle account handy? Generate a **synthetic** file to test the pipeline:

    python -m src.make_sample_data --out data/sample_matches.csv

Synthetic data is only for checking the code runs; its accuracy means nothing.
